import mongoose from 'mongoose';

const ishareSchema = new mongoose.Schema({
 marketvalue: { type: number, required: true },
  avgcost: {
    type: Number, required: true
  },
  ofportfolio: { type: Number, required: true },
  unrealizedpl: { type: Number, required: true, default: false },
});

const ishareModel = mongoose.model('User', ishareSchema);

export default ishareModel;
