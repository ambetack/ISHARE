import React from 'react';
import {useSelector,useDispatch}  from 'react-redux';
 function hookcontainer() {

const marketValue= useSelector(state=>state.marketValue);
const avgcost= useSelector(state=>state.avgcost);
const investedamt= useSelector(state=>state.investedamt);
const ofportfolio= useSelector(state=>state.ofportfolio);
const unrealizedpl= useSelector(state=>state.unrealizedpl);


const dispatch=useDispatch();

    return (
        <div>
            <h1> hook container </h1>
            <h2>  MARKET VALUE = { marketValue } </h2>
            <h2>  AVGCOST = { avgcost } </h2>
            <h2>  INVESTEDAMT = { investedamt } </h2>
            <h2>  OFPORTFOLIO = { ofportfolio } </h2>

            <h2>  UNREALIZEDPL = { unrealizedpl } </h2>





            <button onClick={()=>dispatch(Buy)}> Buy</button>
            <button onClick={()=>dispatch(sell)}> SELL</button>
        </div>
    )
}





export default hookcontainer;
