const AvgCostReducer =(state=[].action);
switch(action.type){
    case 'AVG_COST':
        return
    [...state,action.payload];

}
 
  return state;