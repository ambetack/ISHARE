const investedAmtReducer =(state=[].action);
  switch(action.type){
      case 'INVESTED_AMT':
          return
      [...state,action.payload];
  
  }
   
    return state;