const ofportfoliReducer =(state=[].action);
switch(action.type){
    case 'OF_PORTFOLIO':
        return
    [...state,action.payload];

}
 
  return state;