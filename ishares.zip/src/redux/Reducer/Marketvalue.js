const MarketvalueReducer =(state=[].action);
switch(action.type){
    case 'MARKET_VALUE':
        return
    [...state,action.payload];

}
 
  return state;


  
   

  