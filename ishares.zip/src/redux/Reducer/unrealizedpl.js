const unrealizedplreducer =(state=[].action);
switch(action.type){
    case 'UNREALIZED_PL':
        return
    [...state,action.payload];

}
 
  return state;