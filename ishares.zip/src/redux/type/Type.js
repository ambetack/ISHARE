 export const MARKET_VALUE = 'MARKET_VALUE';
 export const AVG_COST = 'AVG_COST';
 export const INVESTED_AMT = 'INVESTED_AMT';
 export const OF_PORTFOLIO= 'OF_PORTFOLIO';
 export const UNREALIZED_PL = 'UNREALIZED_PL';


