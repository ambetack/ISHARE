import Axios from "axios";
import{AVG_COST,INVESTED_AMT,MARKET_VALUE,OF_PORTFOLIO,UNREALIZED_PL}from "../type/type.js";

const marketvalue = (valueId, qty) => async (dispatch, getState) => {
  try {
    const { data } = await Axios.get("/api/products/" + productId);
    dispatch({
      type: CART_ADD_ITEM, payload: {
        marketvalue: data._id,
        unrealizedpl: data.name,
        avgcost: data.image,
        investedant: data.price,
        ofportfolio: data.countInStock,
        qty
      }
    });

  } catch (error) {

  }
}


export const buyBook