import { createStore, combineReducers, applyMiddleware } from 'redux';
import createSagaMiddleware from 'redux-saga';
import reducer from './reducers';
import mySaga from '.saga';
const store={

    scrip: [],
    Marketvalue:[],
    AvgCost:[],
    investedAmt:[],
    ofPortofoliovalue: [],
    unrealizedPL: [],

    
}



//create the saga Middleware

const sagaMiddleware= createSagaMiddleware()

//mount it on store
const store = createStore(
  reducer,
  applyMiddleware(sagaMiddleware)
);

// then run the saga

sagaMiddleware.run(mySaga)
export default store;
